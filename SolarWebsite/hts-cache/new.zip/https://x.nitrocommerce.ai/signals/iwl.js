<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <link rel="icon shortcut" href="/favicon.ico?v=2" type='image/x-icon' />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>NitroX</title>

  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Geist:wght@100..900&display=swap" rel="stylesheet"/>
  <script id="socket" type="text/javascript" src="https://ray.makehook.ws/javascripts/socket.io.js"></script>
  <!-- <script id="socket-handler" type="text/javascript" src="https://ray.makehook.ws/javascripts/sockethandlers.js"></script> -->
  <script type="module" crossorigin src="/assets/index-D574LtOq.js"></script>
  <link rel="stylesheet" crossorigin href="/assets/index-DYFnIKPj.css">
</head>



<body style="height: 100%">
  <div id="app" style="height: 100%"></div>

  <!-- <script type="module" src="/node_modules/flowbite/dist/flowbite.min.js"></script> -->
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/vce701823e78c4301a35b7e07294d87301792088814092" integrity="sha512-UKNk8GbxkABxKcXYuLkO16EleLGUkcvJWtpSNmExE0Too3ZaFAxTscNWEc1OdAv5/BikHawapSCaiD2XCmp+Bw==" data-cf-beacon='{"version":"2024.11.0","token":"5cf24715d05249aea00c30417efe00af","r":1,"spa":2}' crossorigin="anonymous"></script>
</body>

</html>